# Install the BLACKTERM GitHub Profile

1. On GitHub, create a new public repository named exactly:

   `cojjjj`

2. Turn **Add a README** off when creating it.

3. Extract this pack.

4. Upload both items to the repository root:

   - `README.md`
   - `assets/`

5. Commit the upload.

GitHub will automatically display the README on your profile page because the repository name matches your username.

## Optional Git commands

```powershell
git clone https://github.com/cojjjj/cojjjj.git
cd cojjjj
# Copy README.md and assets into this folder
git add .
git commit -m "feat: launch BLACKTERM operator profile"
git push origin main
```
