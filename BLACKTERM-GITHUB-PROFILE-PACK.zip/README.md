<div align="center">

<img src="./assets/blackterm-hero.svg" alt="BLACKTERM Operator Console" width="100%"/>

<br/>

[![BLACKTERM Platform](https://img.shields.io/badge/BLACKTERM-Platform-00D4FF?style=for-the-badge)](https://github.com/cojjjj/blackterm-platform)
![Status](https://img.shields.io/badge/STATUS-ACTIVE%20DEVELOPMENT-34D399?style=for-the-badge)
![Focus](https://img.shields.io/badge/FOCUS-CYBER%20INVESTIGATION-A855F7?style=for-the-badge)

</div>

## `blackterm> whoami`

```yaml
name: Tyler Deppa
role: Desktop Support Technician
education: Cybersecurity Student
primary_language: Python
current_mission: Build BLACKTERM into a professional investigation platform
interests:
  - Threat Intelligence
  - OSINT
  - Detection Engineering
  - Digital Investigations
  - Security Tool Development
```

## `blackterm> mission --current`

I am building **BLACKTERM**, an autonomous cyber investigation platform that brings reconnaissance, OSINT, threat intelligence, case management, global mapping, relationship analysis, and AI-assisted reporting into one desktop workflow.

<img src="./assets/blackterm-architecture.svg" alt="BLACKTERM Platform Architecture" width="100%"/>

## `blackterm> modules --status`

| Module | Status | Purpose |
|---|---:|---|
| Mission Control | `ONLINE` | Launch and monitor investigations |
| Recon Engine | `ONLINE` | Discover authorized hosts and services |
| OSINT Engine | `ONLINE` | Enrich targets with public-source intelligence |
| Threat Intelligence | `ONLINE` | Analyze indicators and reputation |
| Investigation Workspace | `ONLINE` | Manage cases, evidence, notes, and timelines |
| Global Intelligence Map | `ONLINE` | Visualize geospatial intelligence |
| Relationship Graph | `ONLINE` | Correlate entities across investigations |
| AI Investigation | `ACTIVE` | Summarize findings and recommend next actions |

## `blackterm> showcase --featured`

### BLACKTERM Platform

> My flagship project: a modular desktop platform for authorized reconnaissance, intelligence enrichment, investigation management, visualization, and reporting.

[![View BLACKTERM](https://img.shields.io/badge/OPEN-BLACKTERM%20PLATFORM-00D4FF?style=for-the-badge&logo=github)](https://github.com/cojjjj/blackterm-platform)

### BLACKTERM OS

> An operating-system-inspired cybersecurity portfolio built with React, TypeScript, and Vite.

[![View BLACKTERM OS](https://img.shields.io/badge/OPEN-BLACKTERM%20OS-A855F7?style=for-the-badge&logo=github)](https://github.com/cojjjj/blackterm-os)

## `blackterm> screenshots`

> Add your screenshots to `assets/screenshots/` using these filenames.

| Mission Control | Global Intelligence Map |
|---|---|
| <img src="./assets/screenshots/mission-control.png" width="100%"/> | <img src="./assets/screenshots/global-map.png" width="100%"/> |

| Threat Intelligence | Investigation Explorer |
|---|---|
| <img src="./assets/screenshots/threat-intelligence.png" width="100%"/> | <img src="./assets/screenshots/relationship-graph.png" width="100%"/> |

## `blackterm> skills --list`

<p align="center">

![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![PySide6](https://img.shields.io/badge/PySide6-41CD52?style=for-the-badge&logo=qt&logoColor=white)
![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)
![Windows](https://img.shields.io/badge/Windows-0078D4?style=for-the-badge&logo=windows&logoColor=white)
![Git](https://img.shields.io/badge/Git-F05032?style=for-the-badge&logo=git&logoColor=white)
![Docker](https://img.shields.io/badge/Docker-2496ED?style=for-the-badge&logo=docker&logoColor=white)
![PowerShell](https://img.shields.io/badge/PowerShell-5391FE?style=for-the-badge&logo=powershell&logoColor=white)
![TypeScript](https://img.shields.io/badge/TypeScript-3178C6?style=for-the-badge&logo=typescript&logoColor=white)

</p>

## `blackterm> operator --achievements`

- Top 1% on TryHackMe
- 1000+ completed rooms
- Building a large Python cybersecurity platform
- Desktop support and troubleshooting experience
- Hands-on experience across offensive and defensive security labs

## `blackterm> telemetry --github`

<p align="center">
  <img width="49%" src="https://github-readme-stats.vercel.app/api?username=cojjjj&show_icons=true&theme=tokyonight&hide_border=true&bg_color=0D1117"/>
  <img width="49%" src="https://github-readme-streak-stats.herokuapp.com/?user=cojjjj&theme=tokyonight&hide_border=true&background=0D1117"/>
</p>

<p align="center">
  <img width="48%" src="https://github-readme-stats.vercel.app/api/top-langs/?username=cojjjj&layout=compact&theme=tokyonight&hide_border=true&bg_color=0D1117"/>
</p>

## `blackterm> roadmap --next`

```text
BLACKTERM
├── Autonomous Investigation Workflows
├── Cross-Case Intelligence
├── Investigation Explorer
├── Global Intelligence Mapping
├── AI Correlation
├── Plugin Ecosystem
└── Commercial-Grade Packaging
```

---

<div align="center">

### `NO LOGS. NO WITNESSES. JUST CODE.`

[![GitHub](https://img.shields.io/badge/GitHub-cojjjj-181717?style=for-the-badge&logo=github)](https://github.com/cojjjj)

</div>
